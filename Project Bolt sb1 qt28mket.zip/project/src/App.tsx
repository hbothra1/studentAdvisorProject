import React, { useState } from 'react';
import { Upload, Link, FileText, Send } from 'lucide-react';
import FileUpload from './components/FileUpload';
import TextInput from './components/TextInput';
import UrlInput from './components/UrlInput';
import Results from './components/Results';

function App() {
  const [transcript, setTranscript] = useState<{
    type: 'file' | 'text' | null;
    content: any;
  }>({ type: null, content: null });
  
  const [jobDescription, setJobDescription] = useState<{
    type: 'file' | 'text' | 'url' | null;
    content: any;
  }>({ type: null, content: null });

  const [results, setResults] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleAnalyze = async () => {
    setIsLoading(true);
    try {
      // TODO: Implement API call to backend
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          transcript,
          jobDescription,
        }),
      });
      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error('Error analyzing data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto py-12 px-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">
          Career Path Analyzer
        </h1>
        
        <div className="space-y-8">
          {/* Transcript Section */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Upload Transcript
            </h2>
            <div className="space-y-4">
              <FileUpload
                onFileSelect={(file) => setTranscript({ type: 'file', content: file })}
                acceptedTypes=".pdf"
              />
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">Or enter as text</span>
                </div>
              </div>
              <TextInput
                onTextSubmit={(text) => setTranscript({ type: 'text', content: text })}
                placeholder="Enter your transcript details here..."
              />
            </div>
          </div>

          {/* Job Description Section */}
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Link className="w-5 h-5" />
              Job Description
            </h2>
            <div className="space-y-4">
              <FileUpload
                onFileSelect={(file) => setJobDescription({ type: 'file', content: file })}
                acceptedTypes=".pdf"
              />
              <UrlInput
                onUrlSubmit={(url) => setJobDescription({ type: 'url', content: url })}
              />
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">Or enter as text</span>
                </div>
              </div>
              <TextInput
                onTextSubmit={(text) => setJobDescription({ type: 'text', content: text })}
                placeholder="Enter the job description here..."
              />
            </div>
          </div>

          <button
            onClick={handleAnalyze}
            disabled={!transcript.content || !jobDescription.content || isLoading}
            className="w-full py-3 px-4 border border-transparent rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoading ? (
              'Analyzing...'
            ) : (
              <>
                <Send className="w-5 h-5" />
                Analyze Career Path
              </>
            )}
          </button>

          {results && <Results results={results} />}
        </div>
      </div>
    </div>
  );
}

export default App;