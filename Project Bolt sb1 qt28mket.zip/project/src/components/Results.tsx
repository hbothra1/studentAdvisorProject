import React from 'react';
import { CheckCircle, XCircle, Book } from 'lucide-react';

interface ResultsProps {
  results: {
    requiredSkills: string[];
    missingSkills: string[];
    recommendedCourses: {
      courseId: string;
      name: string;
      description: string;
    }[];
  };
}

const Results: React.FC<ResultsProps> = ({ results }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md space-y-6">
      <h2 className="text-xl font-semibold mb-4">Analysis Results</h2>
      
      <div>
        <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-500" />
          Required Technical Skills
        </h3>
        <ul className="list-disc list-inside space-y-1 pl-4">
          {results.requiredSkills.map((skill, index) => (
            <li key={index} className="text-gray-700">{skill}</li>
          ))}
        </ul>
      </div>

      {results.missingSkills.length > 0 && (
        <div>
          <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
            <XCircle className="w-5 h-5 text-red-500" />
            Skills to Develop
          </h3>
          <ul className="list-disc list-inside space-y-1 pl-4">
            {results.missingSkills.map((skill, index) => (
              <li key={index} className="text-gray-700">{skill}</li>
            ))}
          </ul>
        </div>
      )}

      <div>
        <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
          <Book className="w-5 h-5 text-indigo-500" />
          Recommended Courses
        </h3>
        <div className="space-y-4">
          {results.recommendedCourses.map((course, index) => (
            <div
              key={index}
              className="border border-gray-200 rounded-md p-4 hover:border-indigo-500 transition-colors"
            >
              <h4 className="font-medium">
                {course.courseId}: {course.name}
              </h4>
              <p className="text-sm text-gray-600 mt-1">{course.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Results;