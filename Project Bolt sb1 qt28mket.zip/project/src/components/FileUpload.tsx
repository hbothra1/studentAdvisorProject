import React, { useCallback } from 'react';
import { Upload } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  acceptedTypes: string;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, acceptedTypes }) => {
  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (file && acceptedTypes.includes(file.name.split('.').pop() || '')) {
        onFileSelect(file);
      }
    },
    [onFileSelect, acceptedTypes]
  );

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  };

  return (
    <div
      onDragOver={(e) => e.preventDefault()}
      onDrop={handleDrop}
      className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-indigo-500 transition-colors cursor-pointer"
    >
      <input
        type="file"
        accept={acceptedTypes}
        onChange={handleFileInput}
        className="hidden"
        id="file-upload"
      />
      <label htmlFor="file-upload" className="cursor-pointer">
        <Upload className="mx-auto h-12 w-12 text-gray-400" />
        <p className="mt-2 text-sm text-gray-600">
          Drag and drop a file here, or click to select
        </p>
        <p className="mt-1 text-xs text-gray-500">
          Supported formats: {acceptedTypes}
        </p>
      </label>
    </div>
  );
};

export default FileUpload;